# Ghost Data Still Exists — deterministic audit baseline

## Run

Requires Python 3.10+ and only the Python standard library.

From the repository root (the directory containing `dataset/` and `code/`):

```powershell
python code\main.py
```

The program reads the participant-facing files under `dataset/` and writes `output.csv` to the repository root. It emits one row per request, sorted by numeric case number, with the exact columns `case_id,deletion_status,steps_json`.

This is a deterministic, evidence-retrieval baseline, not a trained AI model. It scans the supplied JSON, SQL, log, and text evidence, attempts to associate records with current/historical identifiers, filters evidence by capture time, classifies resource states, and emits findings/remediation/verification steps. It does not modify any source system or actually execute remediation.

## Important limitations

The supplied evidence is heterogeneous and some evidence is visual/PDF-based. The baseline does not perform OCR or PDF extraction, and its identifier matching and state inference are heuristic. It can miss indirect identity links, overmatch common identifiers, or misclassify policy-specific support and retention cases. Validate `output.csv` carefully before submission. The bundled evaluation report documents measured performance against the public sample outputs rather than claiming hidden-set accuracy.

## Output contract

`output.csv` contains exactly `case_id,deletion_status,steps_json`. Every `steps_json` value is a JSON array; `NOT_APPLICABLE` uses `[]`; step numbers are consecutive. Proposed remediation and future verification steps have an empty `evidence_id`. The tool uses no network access, API keys, or external model provider.

## Files

- `main.py`: runnable audit baseline
- `evaluation/main.py`: output contract validator
- `evaluation/evaluation_report.md`: public-sample evaluation and limitations
- `evaluation/usage_report.md`: model usage and cost disclosure
