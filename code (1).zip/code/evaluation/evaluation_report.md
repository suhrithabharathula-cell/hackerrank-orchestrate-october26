# Evaluation Report

## Public sample benchmark

The implementation was run against `dataset/sample_deletion_requests.csv` and compared with `dataset/sample_output.csv` using the same code path. The sample set has 32 rows.

- **Case-level status accuracy:** 71.88% (23/32).
- **Exact output-row accuracy** (status and entire ordered `steps_json` match): 3.12% (1/32).
- **Step tuple precision:** 15.38% (74 matched predicted step tuples / 481 predicted steps).
- **Step tuple recall:** 38.34% (74 matched expected step tuples / 193 expected steps).
- **Field accuracy at aligned step positions:** 42.69% (508/1190 compared fields). This positional metric compares step_no, phase, system_id, resource_id, operation, state, and evidence_id where both expected and predicted steps exist; it is not a full semantic metric.
- **Sequence accuracy:** exact full-array sequence agreement was 3.12% (same measure as exact output-row accuracy because status must also match in that metric). The low score indicates sequence/resource-level matching needs substantial improvement.

These are measurements on the public sample only. They are not hidden-set accuracy estimates.

## Additional evaluation cases created

These are local unit-test scenarios for output contract behavior (not extra labeled dataset cases):

1. **Explicit non-deletion:** request text “Please do not delete my account.” Expected behavior: `NOT_APPLICABLE` and `[]`.
2. **Authorized deletion with a live search result:** a matched `search_*` record with a positive index hit should create a `REPORT_REMAINING_RECORD` finding and a `DELETE_RECORD` remediation.
3. **Authorized deletion with a live identity connector:** a matched `data_flow_*` connector with `enabled=true` should create `REPORT_ACTIVE_DATA_FLOW`, put `DISABLE_DATA_FLOW` before record-level remediation, and schedule `VERIFY_DATA_FLOW_DISABLED`.
4. **Redacted tombstone:** a matched `tombstone_*` record with direct identifiers set to null should be verified as `REDACTED`, while retaining its stable internal reference.

The cases above define desired behaviors and should be implemented as fixture-based regression tests before treating this baseline as production-ready.

## Failures found

- The baseline misses some expected `COMPLETE` cases because absence is often represented by a missing row in a snapshot rather than a positive record carrying the subject's identifiers.
- Exact step-level agreement is very low. Evidence IDs, account-resource mapping, retained security records, and the canonical verification set are not consistently recovered.
- Some sample cases require PDF/image interpretation or broader point-in-time reconstruction. This implementation does not use OCR or PDF extraction.
- The matching approach is heuristic and can overmatch or undermatch current/historical identifiers.
- Category-specific rules for support attachments, email delivery logs, legal holds, caches, exports, and backup retention need more structured handling.

## Improvements made in this iteration

- Added current and historical identity token collection from `user_identities.csv` and `user_audit_log.csv`.
- Added parsing of JSON evidence, SQL `INSERT` rows, and resource-bearing log lines.
- Filtered evidence by manifest capture time relative to `audit_at`.
- Added operation-phase ordering, consecutive step numbers, valid JSON serialization, and a validator.
- Disclosed the no-LLM deterministic implementation and zero token/cost usage instead of fabricating model usage.

## Validation of the full output

The full run generated 518 rows from `deletion_requests.csv`. The output validator checks the header, row count, unique case IDs, allowed statuses, JSON array syntax, consecutive step numbers, phase names, and empty steps for `NOT_APPLICABLE`. Passing schema validation does not establish correctness of the hidden expected answers.
