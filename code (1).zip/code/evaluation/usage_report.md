# Token Usage and Cost Report

## Full-dataset run

- Implementation: deterministic local Python heuristic; no external language model was used.
- Model provider/name: none.
- Model calls: 0.
- Input tokens: 0 (no model tokenization/API calls).
- Output tokens: 0.
- Total tokens: 0.
- Average tokens per request: 0.
- Estimated total model cost: $0.00.
- Estimated cost per request: $0.00.

The program processed the 518 rows in `dataset/deletion_requests.csv` locally using Python's standard library. These zero-token figures mean no LLM calls were made; they do not imply that the generated predictions are accurate. The approach has known retrieval and evidence-interpretation limitations documented in `evaluation_report.md`.
