#!/usr/bin/env python3
"""Validate the generated output.csv against the project serialization contract."""
import csv, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "dataset"
OUT = ROOT / "output.csv"

def main():
    with (DATA / "deletion_requests.csv").open(encoding="utf-8-sig", newline="") as f:
        expected = list(csv.DictReader(f))
    with OUT.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != ["case_id", "deletion_status", "steps_json"]:
            raise SystemExit(f"Bad header: {reader.fieldnames}")
        rows = list(reader)
    errors=[]
    if len(rows) != len(expected): errors.append(f"row count {len(rows)} != {len(expected)}")
    expected_ids={r["case_id"] for r in expected}
    got_ids=[r["case_id"] for r in rows]
    if len(got_ids)!=len(set(got_ids)): errors.append("duplicate case_id")
    if set(got_ids)!=expected_ids: errors.append("case_id set differs from input")
    natural=lambda x: int(x.split("_")[-1]) if x.split("_")[-1].isdigit() else x
    if got_ids != sorted(got_ids,key=natural): errors.append("rows are not sorted by numeric case_id")
    allowed={"COMPLETE","INCOMPLETE","NOT_APPLICABLE"}
    for row in rows:
        if row["deletion_status"] not in allowed: errors.append(f'{row["case_id"]}: invalid status')
        try: steps=json.loads(row["steps_json"])
        except Exception: errors.append(f'{row["case_id"]}: invalid JSON'); continue
        if not isinstance(steps,list): errors.append(f'{row["case_id"]}: steps_json is not an array'); continue
        if row["deletion_status"]=="NOT_APPLICABLE" and steps: errors.append(f'{row["case_id"]}: NOT_APPLICABLE must have []')
        if [s.get("step_no") for s in steps] != list(range(1,len(steps)+1)):
            errors.append(f'{row["case_id"]}: non-consecutive step_no')
        phase_order={"FINDING":0,"REMEDIATION":1,"VERIFICATION":2}
        if any(s.get("phase") not in phase_order for s in steps): errors.append(f'{row["case_id"]}: invalid phase')
        elif [phase_order[s["phase"]] for s in steps] != sorted(phase_order[s["phase"]] for s in steps):
            errors.append(f'{row["case_id"]}: phases out of order')
    if errors:
        print("\n".join(errors[:50])); print(f"FAIL: {len(errors)} errors"); return 1
    print(f"PASS: {len(rows)} rows; header, IDs, status, JSON, step numbering, phase order validated.")
    return 0
if __name__=="__main__": sys.exit(main())
