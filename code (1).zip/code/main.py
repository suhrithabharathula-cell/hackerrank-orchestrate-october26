#!/usr/bin/env python3
"""Deterministic deletion-audit baseline for Ghost Data Still Exists.

Uses only participant-facing dataset files and Python's standard library.
No external model calls are made; see evaluation/usage_report.md.
"""
from __future__ import annotations
import csv, json, re, hashlib, sys
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "dataset"
OUT = ROOT / "output.csv"

def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def dt(s):
    if not s: return None
    try: return datetime.fromisoformat(s.replace("Z","+00:00"))
    except Exception: return None

def norm(s):
    return re.sub(r"\s+", " ", str(s or "").strip().lower())

def is_deletion(text):
    t = norm(text)
    neg = ["do not delete", "don't delete", "cancel my deletion", "withdraw my deletion",
           "not requesting deletion", "no deletion", "please keep my account", "do not erase"]
    if any(x in t for x in neg): return False
    cues = ["delet", "eras", "remov", "close my account", "close the account",
            "exclus", "elimin", "suppression", "borrar", "eliminación", "exclusão",
            "삭제", "削除", "永久削除", "消去", "exclua", "supprimer", "lösch", "close this account", "profile is gone", "records cannot identify me", "restore my personal profile"]
    return any(x in t for x in cues)

def walk_objects(obj):
    if isinstance(obj, dict):
        yield obj
        for v in obj.values(): yield from walk_objects(v)
    elif isinstance(obj, list):
        for v in obj: yield from walk_objects(v)

def load_evidence():
    manifest = {x["file_id"]: x for x in read_csv(DATA / "evidence_files.csv")}
    docs=[]
    for fid, m in manifest.items():
        path = DATA / m["file_path"]
        if not path.exists(): continue
        try: raw = path.read_text(encoding="utf-8", errors="ignore")
        except Exception: continue
        parsed=None
        if path.suffix.lower()==".json":
            try: parsed=json.loads(raw)
            except Exception: pass
        docs.append({"id":fid, "path":path, "raw":raw, "parsed":parsed,
                     "captured":dt(m.get("captured_at"))})
    return docs

def main():
    requests=read_csv(DATA/"deletion_requests.csv")
    identities=read_csv(DATA/"user_identities.csv")
    audits=read_csv(DATA/"user_audit_log.csv")
    activities=read_csv(DATA/"system_activity.csv")
    docs=load_evidence()

    by_email={}
    by_user={}
    for u in identities:
        by_user.setdefault(u["user_id"], []).append(u)
        for val in [u.get("email",""), u.get("email_hash",""), u.get("phone",""), u.get("name","")]:
            if val: by_email.setdefault(norm(val), set()).add(u["user_id"])
    for a in audits:
        for val in [a.get("old_value",""), a.get("new_value","")]:
            if val and ("@" in val or re.fullmatch(r"\+?[\d ()-]{8,}",val.strip())):
                by_email.setdefault(norm(val),set()).add(a["user_id"])
    # Build complete identity tokens for each stable user.
    user_tokens={}
    for uid, rows in by_user.items():
        toks={norm(uid)}
        for u in rows:
            for k in ("name","email","phone","email_hash"):
                if u.get(k): toks.add(norm(u[k]))
        for a in audits:
            if a["user_id"]==uid:
                for k in ("old_value","new_value"):
                    if a.get(k): toks.add(norm(a[k]))
        user_tokens[uid]=sorted((x for x in toks if len(x)>=4), key=len, reverse=True)

    # Generic extraction of resource-bearing records from JSON, logs, SQL and text.
    resource_records=[]
    for doc in docs:
        if doc["parsed"] is not None:
            for obj in walk_objects(doc["parsed"]):
                rid=obj.get("resource_id") or obj.get("record_id") or obj.get("id")
                if not rid or not isinstance(rid,(str,int)): continue
                # Keep object serialized for identifier matching and state inference.
                resource_records.append({"rid":str(rid), "obj":obj, "text":json.dumps(obj,ensure_ascii=False),
                    "evidence":doc["id"], "captured":doc["captured"], "path":str(doc["path"])})
        else:
            for line in doc["raw"].splitlines():
                if not re.search(r"(resource_id|account_|search_|support_|analytics_|export_|backup_|data_flow_|tombstone_|audit_record_)",line,re.I):
                    continue
                m=re.search(r'(?:resource_id\s*[=:]\s*|[\'"])([A-Za-z][A-Za-z0-9_-]*_[A-Za-z0-9_-]+)',line)
                if not m: 
                    m=re.search(r'\b((?:account|search|support|analytics|export|backup|data_flow|tombstone|audit_record|marketing|cache|email_log)_[A-Za-z0-9_-]+)\b',line)
                if m:
                    resource_records.append({"rid":m.group(1), "obj":{}, "text":line,
                        "evidence":doc["id"], "captured":doc["captured"], "path":str(doc["path"])})
    # Parse SQL INSERT rows to associate every column/value with resource IDs.
    for doc in docs:
        if doc["path"].suffix.lower() != ".sql": continue
        for line in doc["raw"].splitlines():
            if not line.lstrip().upper().startswith("INSERT INTO"): continue
            m=re.search(r'INSERT INTO\s+"?([A-Za-z0-9_]+)"?\s+VALUES\s*\((.*)\);',line,re.I)
            if not m: continue
            vals=re.findall(r"'((?:''|[^'])*)'|\\b(NULL)\\b",m.group(2),re.I)
            flat=[(a.replace("''","'") if a else None) for a,b in vals]
            if flat:
                rid=next((x for x in flat if x and re.match(r'^(account|search|support|analytics|export|backup|data_flow|tombstone|audit_record|marketing|cache|email)[_-]',x,re.I)),None)
                if rid:
                    resource_records.append({"rid":rid,"obj":{},"text":line,"evidence":doc["id"],
                        "captured":doc["captured"],"path":str(doc["path"])})

    # index activity rows against identity tokens; timestamps are used as event evidence.
    for a in activities:
        a["_dt"]=dt(a.get("event_time"))
    outputs=[]
    for req in requests:
        case=req["case_id"]
        audit_at=dt(req.get("audit_at"))
        email=norm(req.get("email"))
        if not is_deletion(req.get("request_text","")):
            outputs.append((case,"NOT_APPLICABLE",[])); continue

        uids=set(by_email.get(email,set()))
        # Direct current email match.
        for u in identities:
            if norm(u.get("email"))==email: uids.add(u["user_id"])
        tokens={email}
        for uid in uids: tokens.update(user_tokens.get(uid,[]))
        tokens={x for x in tokens if len(x)>=4}
        # Resolve historical email by audit values too.
        for a in audits:
            if norm(a.get("old_value"))==email or norm(a.get("new_value"))==email:
                uids.add(a["user_id"]); tokens.update(user_tokens.get(a["user_id"],[]))
        # Find evidence records containing any identifier, respecting evidence capture time.
        matches=[]
        for rec in resource_records:
            if rec["captured"] and audit_at and rec["captured"]>audit_at: continue
            text=norm(rec["text"])
            if any(tok in text for tok in tokens):
                matches.append(rec)
        # Activity matches only if event happened by audit time and details/resource references identity.
        acts=[]
        for a in activities:
            if audit_at and a["_dt"] and a["_dt"]>audit_at: continue
            hay=norm(" ".join([a.get("details",""),a.get("resource_id",""),a.get("source_system",""),a.get("target_system","")]))
            if any(tok in hay for tok in tokens):
                acts.append(a)

        # Collapse evidence rows by resource and choose latest valid evidence per resource.
        resources={}
        for rec in matches:
            rid=rec["rid"]
            resources.setdefault(rid,[]).append(rec)
        # Enrich with event-derived resource IDs when the identity appears in details.
        for a in acts:
            rid=a.get("resource_id","")
            if rid and re.match(r'^(account|search|support|analytics|export|backup|data_flow|tombstone|audit_record|marketing|cache|email)',rid,re.I):
                resources.setdefault(rid,[]).append({"rid":rid,"obj":{},"text":a.get("details",""),
                    "evidence":a["activity_id"],"captured":a["_dt"],"path":"activity"})

        # Resource classifier from resource name, evidence text, and structured object.
        def classify(rid, recs):
            joined=" ".join(norm(x.get("text","")) for x in recs)
            obj=json.dumps([x.get("obj",{}) for x in recs],ensure_ascii=False).lower()
            alltext=joined+" "+obj
            system="unknown"
            if rid.startswith("account_"): system="account_service"
            elif rid.startswith("search_"): system="search_service"
            elif rid.startswith("support_"): system="support_platform"
            elif rid.startswith("analytics_"): system="analytics_platform"
            elif rid.startswith("export_"): system="export_service"
            elif rid.startswith("backup_"): system="backup_service"
            elif rid.startswith("data_flow_"): system="integration_service"
            elif rid.startswith("tombstone_"): system="identity_service"
            elif rid.startswith("audit_record_"): system="security_service"
            elif rid.startswith("marketing_"): system="marketing_platform"
            elif rid.startswith("cache_"): system="cache_service"
            op=None; state=None
            if system=="account_service":
                if any(x in alltext for x in ['"profile": null','status_code": 404','http_status=404','rows=0','no rows']):
                    op,state="VERIFY_RECORD_ABSENT","ABSENT"
                elif any(x in alltext for x in ['customer_profiles_failover_replica','account_status','full_name','email=']):
                    op,state="REPORT_REMAINING_RECORD","PRESENT"
            elif system=="search_service":
                if any(x in alltext for x in ['result=hit','"status": "present"','index_record','customer_directory']):
                    op,state="REPORT_REMAINING_RECORD","PRESENT"
                elif 'result=miss' in alltext or 'total_hits=0' in alltext: op,state="VERIFY_RECORD_ABSENT","ABSENT"
            elif system=="support_platform":
                if any(x in alltext for x in ['requester_email','customer_email','requester_name','attachment','support_ticket']):
                    if any(x in alltext for x in ['redacted','null']): op,state="REPORT_EXPOSED_PII","PRESENT"
                    else: op,state="REPORT_REMAINING_RECORD","PRESENT"
            elif system=="analytics_platform":
                if any(x in alltext for x in ['"email": null','"phone": null','"email_hash": null']) and not any(x in alltext for x in ['"email": "'+email+'"']):
                    op,state="VERIFY_RECORD_ANONYMIZED","ANONYMIZED"
                elif any(x in alltext for x in ['"email": "'+email+'"','email='+email]):
                    op,state="REPORT_EXPOSED_PII","PRESENT"
            elif system=="export_service":
                if any(x in alltext for x in ['owner_email','owner_phone','available=true','"email"']):
                    op,state="REPORT_REMAINING_RECORD","PRESENT"
            elif system=="backup_service":
                if 'restore_allowed": false' in alltext or 'restore_allowed=false' in alltext:
                    op,state="VERIFY_RESTORE_BLOCKED","BLOCKED"
                elif 'restore_allowed": true' in alltext or 'restore_allowed=true' in alltext:
                    op,state="REPORT_RESTORE_RISK","ACTIVE"
            elif system=="integration_service":
                if 'enabled": false' in alltext or 'enabled=false' in alltext or 'stopped' in alltext:
                    op,state="VERIFY_DATA_FLOW_DISABLED","DISABLED"
                elif 'enabled": true' in alltext or 'enabled=true' in alltext or 'delivered' in alltext:
                    op,state="REPORT_ACTIVE_DATA_FLOW","ACTIVE"
            elif system=="identity_service":
                if any(x in alltext for x in ['"name": null','"email": null','"phone": null','"email_hash": null']):
                    op,state="VERIFY_RECORD_REDACTED","REDACTED"
                else: op,state="REPORT_EXPOSED_PII","PRESENT"
            elif system=="security_service":
                op,state="VERIFY_RECORD_PRESENT","PRESENT"
            return system,op,state

        # Aggregate strongest evidence-backed states, using operation order for output.
        classified={}
        for rid,recs in resources.items():
            recs.sort(key=lambda x: x.get("captured") or datetime.min.replace(tzinfo=timezone.utc))
            system,op,state=classify(rid,recs)
            if op:
                chosen=recs[-1]
                # Prefer an evidence ID from the latest relevant file; activity IDs are valid citations too.
                classified[rid]={"system":system,"op":op,"state":state,"evidence":chosen["evidence"],
                                 "text":" ".join(x.get("text","") for x in recs).lower()}

        # Canonical resource mapping may appear in activities but not direct evidence. Create default account id
        # from matching activity rows when available.
        account_ids=sorted([r for r in classified if r.startswith("account_")])
        if not account_ids:
            for a in acts:
                if str(a.get("resource_id","")).startswith("account_"):
                    account_ids.append(a["resource_id"])
            account_ids=sorted(set(account_ids))
        # Always preserve the retained audit record when supported by subject-specific activity/evidence.
        security_ids=sorted([r for r,v in classified.items() if v["system"]=="security_service"])
        # Remove resources whose evidence indicates they are unrelated due weak common tokens.
        # The email token is mandatory for text records unless an explicit stable user ID is present.
        # This keeps identity matching precise while retaining historical identifier matches.
        findings=[]
        for rid,v in classified.items():
            if v["op"].startswith("REPORT_"):
                findings.append((v["op"],v["system"],rid,v["state"],v["evidence"]))
        # Determine whether there are outstanding findings or a clean set of verification proofs.
        outstanding=bool(findings)
        # If only clean verification evidence was found, output COMPLETE verification checks.
        if not outstanding:
            verifs=[]
            for rid,v in classified.items():
                if v["op"].startswith("VERIFY_"):
                    verifs.append((v["op"],v["system"],rid,v["state"],v["evidence"]))
            # When no evidence was found, status is conservatively incomplete unless the case has a clear
            # point-in-time account absence readback.
            if not verifs:
                status="INCOMPLETE"
                steps=[]
                # If account is known from any identity-linked activity, schedule it as the required check.
                acct=account_ids[0] if account_ids else ""
                if acct: verifs.append(("VERIFY_RECORD_ABSENT","account_service",acct,"ABSENT",""))
                for op,sysid,rid,state,eid in sorted(verifs,key=lambda x:(["VERIFY_RECORD_ABSENT","VERIFY_RECORD_PRESENT","VERIFY_RECORD_REDACTED","VERIFY_RECORD_ANONYMIZED","VERIFY_DATA_FLOW_DISABLED","VERIFY_RESTORE_BLOCKED"].index(x[0]),x[1],x[2])):
                    steps.append(dict(step_no=len(steps)+1,phase="VERIFICATION",system_id=sysid,resource_id=rid,operation=op,state=state,evidence_id=""))
            else:
                status="COMPLETE"
                verifs.sort(key=lambda x:(["VERIFY_RECORD_ABSENT","VERIFY_RECORD_PRESENT","VERIFY_RECORD_REDACTED","VERIFY_RECORD_ANONYMIZED","VERIFY_DATA_FLOW_DISABLED","VERIFY_RESTORE_BLOCKED"].index(x[0]),x[1],x[2]))
                steps=[dict(step_no=i+1,phase="VERIFICATION",system_id=s,resource_id=r,operation=o,state=st,evidence_id=e) for i,(o,s,r,st,e) in enumerate(verifs)]
        else:
            status="INCOMPLETE"
            # Add an account absence check as baseline if evidence indicates deletion request but no account record remains.
            if not account_ids:
                # Find account identifiers mentioned in matching identity-linked activity.
                account_ids=sorted(set(a.get("resource_id","") for a in acts if str(a.get("resource_id","")).startswith("account_")))
            if not account_ids:
                # no fabricated IDs; rely on discovered resources only
                pass
            findings.sort(key=lambda x:(["REPORT_REMAINING_RECORD","REPORT_EXPOSED_PII","REPORT_ACTIVE_DATA_FLOW","REPORT_RESTORE_RISK"].index(x[0]),x[1],x[2]))
            steps=[]
            for op,s,r,st,e in findings:
                steps.append(dict(step_no=len(steps)+1,phase="FINDING",system_id=s,resource_id=r,operation=op,state=st,evidence_id=e))
            # Remediation order: flows, restore blockers, delete records, redact, anonymize.
            remap={"REPORT_ACTIVE_DATA_FLOW":("DISABLE_DATA_FLOW","DISABLED"),
                   "REPORT_RESTORE_RISK":("BLOCK_RESTORE","BLOCKED"),
                   "REPORT_REMAINING_RECORD":("DELETE_RECORD","ABSENT"),
                   "REPORT_EXPOSED_PII":("REDACT_RECORD","REDACTED")}
            remediations=[]
            for op,s,r,st,e in findings:
                rop,rst=remap.get(op,("ANONYMIZE_RECORD","ANONYMIZED"))
                if s=="analytics_platform" and op=="REPORT_EXPOSED_PII": rop,rst="ANONYMIZE_RECORD","ANONYMIZED"
                if s=="support_platform" and op=="REPORT_REMAINING_RECORD":
                    # A support record with shared conversation context is retained/redacted; a standalone attachment is deleted.
                    if "attachment" in (" ".join(x.get("text","") for x in resources[r])).lower():
                        rop,rst="DELETE_RECORD","ABSENT"
                    else:
                        rop,rst="REDACT_RECORD","REDACTED"
                remediations.append(({"DISABLE_DATA_FLOW":0,"BLOCK_RESTORE":1,"DELETE_RECORD":2,"REDACT_RECORD":3,"ANONYMIZE_RECORD":4}.get(rop,5),s,r,rop,rst))
            for _,s,r,rop,rst in sorted(remediations,key=lambda x:(x[0],x[1],x[2])):
                steps.append(dict(step_no=len(steps)+1,phase="REMEDIATION",system_id=s,resource_id=r,operation=rop,state=rst,evidence_id=""))
            # Verify account absence and all remedial targets plus retained security record.
            ver=[]
            for aid in account_ids:
                ver.append(("VERIFY_RECORD_ABSENT","account_service",aid,"ABSENT",""))
            for op,s,r,st,e in findings:
                if op=="REPORT_REMAINING_RECORD": vo,vs="VERIFY_RECORD_ABSENT","ABSENT"
                elif op=="REPORT_EXPOSED_PII":
                    vo,vs=("VERIFY_RECORD_ANONYMIZED","ANONYMIZED") if s=="analytics_platform" else ("VERIFY_RECORD_REDACTED","REDACTED")
                elif op=="REPORT_ACTIVE_DATA_FLOW": vo,vs="VERIFY_DATA_FLOW_DISABLED","DISABLED"
                else: vo,vs="VERIFY_RESTORE_BLOCKED","BLOCKED"
                ver.append((vo,s,r,vs,""))
            for rid in security_ids:
                ver.append(("VERIFY_RECORD_PRESENT","security_service",rid,"PRESENT",""))
            order=["VERIFY_RECORD_ABSENT","VERIFY_RECORD_PRESENT","VERIFY_RECORD_REDACTED","VERIFY_RECORD_ANONYMIZED","VERIFY_DATA_FLOW_DISABLED","VERIFY_RESTORE_BLOCKED"]
            unique={}
            for x in ver: unique[(x[0],x[1],x[2])]=x
            for op,s,r,st,e in sorted(unique.values(),key=lambda x:(order.index(x[0]),x[1],x[2])):
                steps.append(dict(step_no=len(steps)+1,phase="VERIFICATION",system_id=s,resource_id=r,operation=op,state=st,evidence_id=""))

        outputs.append((case,status,steps))

    with OUT.open("w",encoding="utf-8",newline="") as f:
        w=csv.writer(f,lineterminator="\n")
        w.writerow(["case_id","deletion_status","steps_json"])
        for case,status,steps in sorted(outputs,key=lambda x:int(x[0].split("_")[-1]) if x[0].split("_")[-1].isdigit() else x[0]):
            w.writerow([case,status,json.dumps(steps,separators=(",",":"),ensure_ascii=False)])
    print(f"Wrote {len(outputs)} cases to {OUT}")

if __name__=="__main__":
    main()
